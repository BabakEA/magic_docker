# magic_docker
Magic Docker is an automated tools to build a Docker Image


Hi there 
I hope all is well, and you are enjoying the time. 

You are using the Magic_Docker Tools. It is an automated python application to create an error-free Docker Image. 

The current version has been programmed for Linux Os if you are a Linux user, good news! Magic _docker will take care of all the steps. Please sweet yourself and enjoy the show. 
If you are windows or MAC user, Magic docker still will help you. I will create the Dockerfile, requirements, and the shell script to build and save the created docker image. 
You need to run the shell command manually. 

Please feel free to contact me if you needed any further assistance. 

Thank you. 

Babak.EA


How to run : 

<b> using Jupyter notbook </b> 

import magic_docker

magic_docker.J_Magic_Docker()

source code : github
https://github.com/BabakEA/magic_docker

PyPi : 
pip install magic_docker 
